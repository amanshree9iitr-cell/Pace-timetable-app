PACE IIT & Medical logo assets

Use these assets in the existing PACE web app root alongside index.html.
- icon-180.png: iOS/iPadOS Apple touch icon
- icon-192.png and icon-512.png: Android/PWA install icons
- favicon-32.png: browser tab icon

In index.html, use: <link rel="apple-touch-icon" href="icon-180.png"> and <link rel="icon" type="image/png" sizes="32x32" href="favicon-32.png">.
In manifest.webmanifest, list icon-192.png (192x192) and icon-512.png (512x512) as PNG icons.
Upload/commit the assets to the same deployed app root, then redeploy. On phones, remove the old home-screen shortcut and add it again if the old icon remains cached.
